"""Genera manual_economico.pdf. Dependencias de autoría opcionales: reportlab, matplotlib.

La aplicación Streamlit NO requiere este script ni estas dos dependencias.
"""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    Image, KeepTogether, HRFlowable
)
from reportlab.lib.colors import HexColor
from modelo import Mercado, equilibrio, reaccion1, reaccion2

ROOT = Path(__file__).resolve().parent
PAGINA_W, PAGINA_H=A4
NAVY=HexColor("#10243B")
AZUL=HexColor("#2563EB")
CELESTE=HexColor("#DFEFFF")
VERDE=HexColor("#16A34A")
NARANJA=HexColor("#E59728")
GRIS=HexColor("#5D7084")
LIGERO=HexColor("#F2F6FB")
BLANCO=colors.white

for nombre,ruta in [("Lato","/usr/share/fonts/truetype/lato/Lato-Regular.ttf"),
                    ("Lato-Bold","/usr/share/fonts/truetype/lato/Lato-Bold.ttf"),
                    ("Lato-Black","/usr/share/fonts/truetype/lato/Lato-Black.ttf")]:
    if Path(ruta).exists():pdfmetrics.registerFont(TTFont(nombre,ruta))
REGULAR = "Lato" if "Lato" in pdfmetrics.getRegisteredFontNames() else "Helvetica"
NEGRITA = "Lato-Bold" if "Lato-Bold" in pdfmetrics.getRegisteredFontNames() else "Helvetica-Bold"
SUPER = "Lato-Black" if "Lato-Black" in pdfmetrics.getRegisteredFontNames() else NEGRITA

body=ParagraphStyle("Body",fontName=REGULAR,fontSize=10.4,leading=15.8,textColor=NAVY,spaceAfter=10)
small=ParagraphStyle("Small",parent=body,fontSize=9.2,leading=13.7,spaceAfter=7)
h1=ParagraphStyle("H1",fontName=SUPER,fontSize=21,leading=26,textColor=NAVY,spaceAfter=14,spaceBefore=1)
h2=ParagraphStyle("H2",fontName=NEGRITA,fontSize=12.4,leading=17,textColor=AZUL,spaceBefore=13,spaceAfter=7)
formula=ParagraphStyle("Formula",fontName=NEGRITA,fontSize=11,leading=17,textColor=NAVY,
                       leftIndent=15,spaceBefore=3,spaceAfter=8)
caption=ParagraphStyle("Caption",fontName=REGULAR,fontSize=8.3,leading=12,textColor=GRIS,spaceAfter=8)
white_title=ParagraphStyle("WhiteTitle",fontName=SUPER,fontSize=49,leading=55,textColor=BLANCO)
white_sub=ParagraphStyle("WhiteSub",fontName=NEGRITA,fontSize=18,leading=24,textColor=HexColor("#D5E9FF"))
white_body=ParagraphStyle("WhiteBody",fontName=REGULAR,fontSize=11.8,leading=18,textColor=HexColor("#C6DDF6"))


def P(t,style=body):return Paragraph(t,style)
def T(data,widths=None,header=True):
    data=[[P(str(cell),small) if not isinstance(cell,Paragraph) else cell for cell in row] for row in data]
    tabla=Table(data,colWidths=widths,repeatRows=1 if header else 0,hAlign="LEFT")
    reglas=[("VALIGN",(0,0),(-1,-1),"MIDDLE"),
            ("LEFTPADDING",(0,0),(-1,-1),9), ("RIGHTPADDING",(0,0),(-1,-1),9),
            ("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7),
            ("LINEBELOW",(0,-1),(-1,-1),.5,HexColor("#DBE5EF"))]
    if header:
        reglas += [("BACKGROUND",(0,0),(-1,0),CELESTE),
                   ("ROWBACKGROUNDS",(0,1),(-1,-1),[BLANCO,LIGERO])]
    tabla.setStyle(TableStyle(reglas))
    return tabla


def cabecera_pagina(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0,PAGINA_H-11*mm,PAGINA_W,11*mm,stroke=0,fill=1)
    canvas.setFillColor(BLANCO)
    canvas.setFont(NEGRITA,8)
    canvas.drawString(18*mm,PAGINA_H-7*mm,"LOS OPTIMOS / MICROECONOMÍA II")
    canvas.drawRightString(PAGINA_W-18*mm,PAGINA_H-7*mm,"MANUAL ECONÓMICO")
    canvas.setFillColor(GRIS)
    canvas.setFont(REGULAR,8)
    canvas.drawString(18*mm,13*mm,"Universidad de La Sabana  ·  Taller 5 / Reto 4")
    canvas.drawRightString(PAGINA_W-18*mm,13*mm,f"{doc.page:02d}")
    canvas.restoreState()


def portada(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0,0,PAGINA_W,PAGINA_H,stroke=0,fill=1)
    canvas.setFillColor(HexColor("#143B69"))
    canvas.circle(PAGINA_W+42*mm,PAGINA_H-40*mm,105*mm,fill=1,stroke=0)
    canvas.setFillColor(HexColor("#1F5698"))
    canvas.circle(PAGINA_W+55*mm,-10*mm,108*mm,fill=1,stroke=0)
    canvas.setStrokeColor(HexColor("#4074AF"))
    canvas.setLineWidth(3)
    canvas.line(28*mm,53*mm,PAGINA_W-26*mm,75*mm)
    canvas.line(28*mm,67*mm,PAGINA_W-26*mm,110*mm)
    canvas.setFillColor(HexColor("#D4E6FA"))
    canvas.setFont(NEGRITA,9)
    canvas.drawString(24*mm,17*mm,"UNIVERSIDAD DE LA SABANA  |  TALLER 5 - RETO 4")
    canvas.restoreState()


def grafica_estatica():
    fig,ax=plt.subplots(figsize=(8.4,4.0),dpi=180)
    valores=np.linspace(0,90,200)
    m=Mercado()
    ax.plot([reaccion1(m,y) for y in valores],valores,color="#2563eb",lw=3,label="R1: q1 = BR1(q2)")
    ax.plot(valores,[reaccion2(m,x) for x in valores],color="#16a34a",lw=3,label="R2: q2 = BR2(q1)")
    r=equilibrio(m)
    ax.scatter([r.q1],[r.q2],s=95,zorder=5,color="#f59e0b",edgecolor="white",linewidth=1.6)
    ax.annotate("E (26.67, 26.67)",(r.q1,r.q2),xytext=(34,37),
                arrowprops=dict(arrowstyle="-",color="#7a8b9c"),fontsize=10)
    ax.set_xlabel("Producción empresa 1 (q1)")
    ax.set_ylabel("Producción empresa 2 (q2)")
    ax.set_xlim(0,85);ax.set_ylim(0,85)
    ax.grid(True,color="#e7edf5")
    ax.spines[["top","right"]].set_visible(False)
    ax.legend(loc="upper right",fontsize=8.4)
    fig.tight_layout(pad=1)
    ruta=ROOT/"assets"/"curvas_cournot_ejemplo.png"
    fig.savefig(ruta,bbox_inches="tight",facecolor="white")
    plt.close(fig)
    return ruta


def main():
    ruta_grafica=grafica_estatica()
    ruta=ROOT/"manual_economico.pdf"
    doc=SimpleDocTemplate(str(ruta),pagesize=A4,
                          leftMargin=19*mm,rightMargin=19*mm,
                          topMargin=20*mm,bottomMargin=22*mm,
                          title="LOS OPTIMOS | Manual económico del simulador de Cournot",
                          author="Grupo LOS OPTIMOS",subject="Microeconomía II, duopolio de Cournot")
    W=PAGINA_W-38*mm
    elementos=[]
    def add(*x):elementos.extend(x)
    def salto():elementos.append(PageBreak())

    # Portada
    add(Spacer(1,42*mm),P("MANUAL ECONÓMICO",white_sub),Spacer(1,10*mm),
        P("LOS<br/>OPTIMOS",white_title),Spacer(1,10*mm),
        P("Simulador interactivo de duopolio de Cournot",white_sub),Spacer(1,9*mm),
        P("Competencia en cantidades · funciones de reacción · equilibrio de Nash · "
          "decisiones individuales · análisis de escenarios",white_body))
    salto()
    # Pagina 2
    add(P("01  |  El problema económico",h1),
        P("<b>Pregunta central:</b> ¿cómo decide una empresa cuánto producir cuando su beneficio depende de la cantidad que ofrece su rival?"),
        P("En un duopolio de Cournot, dos empresas eligen simultáneamente sus cantidades. "
          "La cantidad total determina el precio; por eso la decisión de una firma altera los ingresos de ambas."),
        P("Supuestos del modelo",h2),
        T([["Supuesto","Significado en el simulador"],
           ["Dos empresas", "Existen únicamente empresa 1 y empresa 2."],
           ["Bien homogéneo", "Ambas venden el mismo producto al precio del mercado."],
           ["Elección simultánea", "Cada una fija su cantidad tomando la del rival como dada."],
           ["Demanda inversa lineal", "P = a − b(q1 + q2), con a ≥ 0 y b > 0."],
           ["Costos marginales constantes", "C1 = c1q1 y C2 = c2q2, sin costos fijos."],
           ["Cantidades no negativas", "q1 ≥ 0, q2 ≥ 0. Los costos c1 y c2 no son negativos."]],
          [W*.28,W*.72]),
        P("Precio y costos",h2),
        P("P = a − bQ, &nbsp;&nbsp; Q = q1 + q2",formula),
        P("C1(q1) = c1 q1 &nbsp;&nbsp;&nbsp; C2(q2) = c2 q2",formula),
        P("El intercepto <b>a</b> aproxima la máxima disposición a pagar cuando Q=0. "
          "La pendiente <b>b</b> refleja cuánto baja el precio por cada unidad extra de producción total. "
          "Cada <b>ci</b> indica el costo de producir una unidad adicional."))
    salto()
    # Pagina 3
    add(P("02  |  Beneficios y mejores respuestas",h1),
        P("Una empresa maximiza su beneficio como diferencia entre ingreso y costo: "
          "πi = Pi·qi − ci·qi. Como ambas venden a P, sus cantidades afectan el mismo precio."),
        P("π1 = [a − b(q1 + q2) − c1] q1",formula),
        P("π2 = [a − b(q1 + q2) − c2] q2",formula),
        P("Derivación de la empresa 1",h2),
        P("π1 = (a − c1)q1 − b q1² − b q1q2",formula),
        P("∂π1/∂q1 = a − c1 − 2b q1 − b q2 = 0",formula),
        P("q1 = (a − c1 − b q2)/(2b)",formula),
        P("Como ∂²π1/∂q1² = −2b &lt; 0, el beneficio es estrictamente cóncavo en q1. "
          "Por tanto, la condición de primer orden caracteriza el máximo interior."),
        P("Para la empresa 2, el proceso es simétrico",h2),
        P("∂π2/∂q2 = a − c2 − 2b q2 − b q1 = 0",formula),
        P("q2 = (a − c2 − b q1)/(2b)",formula),
        P("Restricción de producción y complementariedad",h2),
        P("Como no se puede producir una cantidad negativa, se reemplaza cada respuesta libre por su máximo con cero:"),
        P("BR1(q2) = máx{0, (a − c1 − b q2)/(2b)}",formula),
        P("BR2(q1) = máx{0, (a − c2 − b q1)/(2b)}",formula),
        P("En un óptimo con qi &gt; 0, el beneficio marginal es cero; si qi = 0, "
          "el beneficio marginal no puede ser positivo. Estas son las condiciones de complementariedad del problema."))
    salto()
    # Pagina 4
    add(P("03  |  Encontrar el equilibrio",h1),
        P("En Cournot hay equilibrio cuando las dos mejores respuestas son consistentes entre sí: "
          "q1* = BR1(q2*) y q2* = BR2(q1*). Ninguna empresa gana al cambiar por sí sola su cantidad."),
        P("Solución interior",h2),
        P("Si q1* &gt; 0 y q2* &gt; 0, se resuelve el sistema de condiciones de primer orden:"),
        P("2b q1 + b q2 = a − c1",formula),
        P("b q1 + 2b q2 = a − c2",formula),
        P("q1* = (a − 2c1 + c2)/(3b)",formula),
        P("q2* = (a − 2c2 + c1)/(3b)",formula),
        P("P* = (a + c1 + c2)/3; &nbsp;&nbsp; πi* = (P* − ci) qi*",formula),
        P("<b>Condición indispensable:</b> ambas cantidades interiores deben ser estrictamente positivas. "
          "No se permite presentar una cantidad interior negativa ni reemplazarla por cero conservando sin más la otra fórmula interior."),
        P("Casos de esquina",h2),
        T([["Caso", "Cantidad candidata y condición de mejor respuesta rival"],
           ["Solo produce E1", "q1 = máx{0,(a−c1)/(2b)}, q2 = 0; exigir BR2(q1)=0."],
           ["Solo produce E2", "q1 = 0, q2 = máx{0,(a−c2)/(2b)}; exigir BR1(q2)=0."],
           ["Ninguna produce", "q1=q2=0 si a ≤ c1 y a ≤ c2."],
           ["Ambas producen", "Usar las fórmulas interiores solo cuando ambas q son positivas."]],
          [W*.28,W*.72]),
        P("Se verifica finalmente q1* = BR1(q2*) y q2* = BR2(q1*), además de q1*, q2* ≥ 0.",small))
    salto()
    # Pagina 5
    r=equilibrio(Mercado())
    add(P("04  |  Ejemplo base: validación",h1),
        P("Parámetros precargados: <b>a = 100, b = 1, c1 = 20, c2 = 20</b>."),
        P("q1* = (100 − 40 + 20)/3 = 80/3 = 26,67",formula),
        P("q2* = (100 − 40 + 20)/3 = 80/3 = 26,67",formula),
        P("Q* = 160/3 = 53,33; &nbsp; P* = (100 + 20 + 20)/3 = 46,67",formula),
        P("π1* = π2* = (46,67 − 20) × 26,67 ≈ 711,11",formula),
        T([["Indicador","Resultado exacto","Visualización"],
           ["q1*, q2*","80/3 cada una","26,67"],
           ["Q*","160/3","53,33"],
           ["P*","140/3","46,67"],
           ["π1*, π2*","6400/9 cada uno","711,11"]],
          [W*.38,W*.32,W*.30]),
        Spacer(1,6*mm),Image(str(ruta_grafica),width=W*.94,height=W*.47),
        P("Funciones de reacción con ejes correctos: q1 horizontal, q2 vertical. "
          "El punto naranja representa (26,67; 26,67). Elaboración propia.",caption))
    salto()
    # Pagina 6
    add(P("05  |  Interpretar cambios de mercado",h1),
        P("Los efectos siguientes se formulan para <b>comparaciones dentro de un régimen interior</b>. "
          "En los cambios hacia o desde una esquina, una de las cantidades puede quedarse en cero, "
          "por lo que se deben contrastar los resultados efectivos."),
        T([["Cambio","Interpretación económica"],
           ["Aumenta c1", "La mejor respuesta de E1 disminuye. En el interior, q1 cae, q2 sube y P aumenta."],
           ["Disminuye c2", "La mejor respuesta de E2 aumenta. En el interior, q2 sube y q1 baja."],
           ["Aumenta a", "Mayor precio disponible para cada Q; en el interior aumentan ambas cantidades."],
           ["Aumenta b", "El precio cae más rápido con Q. En el interior disminuyen las cantidades; P* no depende de b."]],
          [W*.26,W*.74]),
        P("Ejemplo: aumenta el costo de la empresa 1",h2),
        P("Con a=100, b=1, c1=35 y c2=20, la solución interior pasa a:"),
        P("q1* = 50/3 ≈ 16,67; q2* = 95/3 ≈ 31,67; P* = 155/3 ≈ 51,67",formula),
        P("π1* = 2500/9 ≈ 277,78; π2* = 9025/9 ≈ 1002,78",formula),
        P("La empresa con mayor costo reduce su participación, mientras la rival expande la producción. "
          "El precio de mercado aumenta por la caída en la cantidad total."),
        P("Ejemplo: equilibrio de esquina",h2),
        P("Con a=100, b=1, c1=95 y c2=20, la firma 1 elige q1=0 y la 2 q2=40. "
          "El precio es P=60. La empresa 2 obtiene π2=(60−20)×40=1600; la 1 obtiene cero. "
          "El resultado interior incorrecto para q1 sería negativo; por eso se descarta."))
    salto()
    # Pagina 7
    add(P("06  |  Cómo utilizar la aplicación",h1),
        P("<b>1. Portada:</b> pulsa «Comenzar simulación». El punto de partida contiene los parámetros del ejemplo validado."),
        P("<b>2. Panel de mercado:</b> cambia a, b, c1 o c2 con deslizadores o campos numéricos. "
          "Todos los resultados y gráficos se actualizan al confirmar un nuevo valor."),
        P("<b>3. Resumen:</b> revisa cantidades, producción total, precio, beneficios, tipo de equilibrio "
          "y las diferencias respecto a la referencia seleccionada."),
        P("<b>4. Reacciones y equilibrio:</b> las curvas azules y verdes sólidas muestran las nuevas "
          "mejores respuestas; las discontinuas muestran las de referencia. El punto resaltado es el equilibrio. "
          "Mueve la cantidad rival para observar la respuesta de cada empresa."),
        P("<b>5. Decisión individual:</b> escoge ser gerente de empresa 1 o 2, mantén fija la producción "
          "rival (de equilibrio o manual) y elige tu cantidad. La aplicación compara tu beneficio "
          "con el máximo posible y con la cantidad de Cournot."),
        P("<b>6. Resultados:</b> separa la producción en equilibrio de la decisión manual. "
          "Visualiza precio, ingresos, costos y beneficios. Descarga los datos en CSV."),
        P("<b>7. Escenarios:</b> compara el inicial con cuatro alternativas, guarda tus parámetros actuales "
          "con un nombre y agrega alternativas. Exporta los casos a JSON para conservarlos y vuelve "
          "a importarlos si cierras la sesión."),
        P("<b>8. Seleccionar referencia:</b> en la barra lateral elige Inicial o un escenario guardado. "
          "El gráfico actualizará su superposición para mostrar desplazamientos de las curvas."),
        P("La idea económica detrás del juego",h2),
        P("Si el rival produce más, tu ingreso marginal cae. En general, reaccionas "
          "produciendo menos. La intersección de mejores respuestas define la decisión estable "
          "en el modelo de cantidades simultáneas."),
        P("Las unidades monetarias son genéricas. El modelo no incluye incertidumbre, costos fijos, "
          "diferenciación de productos, múltiples períodos ni decisiones secuenciales.",small))
    salto()
    # Pagina 8
    add(P("07  |  Revisión y pruebas",h1),
        P("El simulador incorpora un módulo matemático separado de la interfaz. "
          "Esto permite revisar la teoría y probar los cálculos sin depender del navegador."),
        P("Comprobaciones del núcleo económico",h2),
        T([["Validación","Criterio"],
           ["Caso inicial", "26,67; 26,67; 53,33; 46,67; π1=π2=711,11."],
           ["Cuatro parámetros", "Cambiar a, b, c1 y c2 por separado y recalcular."],
           ["Esquinas", "Firmas individuales inactivas y mercado sin producción."],
           ["Restricciones", "Comprobar q1, q2 ≥ 0 y las dos condiciones de mejor respuesta."],
           ["Mejor respuesta", "No existe desviación unilateral que mejore beneficios."],
           ["Curvas correctas", "En R1 se representa (BR1(q2),q2), y en R2 (q1,BR2(q1))."],
           ["Decisión manual", "Comparación separada de la decisión de equilibrio."]],
          [W*.28,W*.72]),
        P("Cómo reproducir las pruebas",h2),
        P("En una terminal abierta dentro de LOS_OPTIMOS, con las dependencias instaladas:"),
        P("python -m pip install pytest",formula),
        P("python -m pytest -q",formula),
        P("El archivo tests/test_modelo.py valida casos interiores, esquinas y miles de "
          "parámetros aleatorios, además de la orientación de las curvas y los efectos económicos."),
        P("Límites y uso responsable",h2),
        P("Este instrumento representa un modelo teórico. El precio se obtiene de una demanda lineal "
          "y la sección de decisión manual limita las cantidades para que Q no supere a/b. "
          "La predicción no debe interpretarse como un pronóstico de una industria real sin calibración."),
        Spacer(1,8*mm),HRFlowable(width="100%",thickness=1,color=CELESTE),
        P("<b>LOS OPTIMOS</b> · Manual académico de elaboración propia. "
          "Microeconomía II · Taller 5 – Reto 4 · Universidad de La Sabana.",caption))

    doc.build(elementos,onFirstPage=portada,onLaterPages=cabecera_pagina)
    print(f"PDF creado: {ruta}")


if __name__=="__main__":main()

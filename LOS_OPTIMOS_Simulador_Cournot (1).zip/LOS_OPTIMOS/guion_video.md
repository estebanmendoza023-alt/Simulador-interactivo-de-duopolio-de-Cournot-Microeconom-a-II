# LOS OPTIMOS — Guion para video demostrativo (4:40)

**Presentan:** grupo LOS OPTIMOS · Microeconomía II · Universidad de La Sabana

**0:00–0:35 | Introducción (portada)**
«Somos LOS OPTIMOS. Este simulador estudia el duopolio de Cournot: dos empresas eligen cuánto producir simultáneamente. El precio depende de la suma de sus cantidades, así que lo que hace una empresa afecta los incentivos de la otra».

**0:35–1:15 | Modelo y validación (resumen)**
«Partimos de una demanda inversa P = a − b(q1 + q2) y costos lineales C1=c1 q1 y C2=c2 q2. Con a=100, b=1 y costos iguales a 20, el simulador da 26,67 unidades a cada una, 53,33 en total, precio 46,67 y beneficio 711,11 para cada empresa. Son los resultados del equilibrio interior».

**1:15–2:05 | Reacciones (pestaña Reacciones)**
«La curva azul muestra la cantidad óptima de la empresa 1 para cada producción de la 2. La verde hace lo mismo para la empresa 2. Su intersección es el equilibrio de Cournot. Al aumentar la producción rival, la mejor respuesta propia tiende a disminuir. Importante: las curvas están dibujadas con q1 en el eje X y q2 en el eje Y».

**2:05–2:55 | Cambiar los costos (barra lateral + gráfica)**
«Subimos el costo de la empresa 1 de 20 a 35. Esto desplaza su función de reacción, reduce su producción óptima y puede permitir que la rival aumente la suya. Las curvas discontinuas muestran el punto de partida y las sólidas el escenario actual. Los resultados se actualizan en tiempo real. La interpretación se ajusta a las cantidades calculadas, incluso cuando una empresa deja de producir».

**2:55–3:40 | Decisión de un gerente (pestaña Decisión individual)**
«Nos ponemos en el papel de la empresa 1. Mantenemos fija la producción de la empresa 2 y elegimos manualmente nuestra cantidad. En el gráfico vemos nuestro beneficio y la cantidad que lo maximiza. Si producimos por encima o por debajo de la mejor respuesta, dejamos de ganar frente al máximo posible. Esa mejor respuesta no siempre coincide con la cantidad de Cournot si el rival produce algo diferente a su equilibrio».

**3:40–4:20 | Resultados y escenarios**
«En Resultados comparamos claramente el equilibrio con la decisión manual: producción, precio, ingresos, costos y beneficios. En Escenarios vemos aumentos de costos y demanda, guardamos situaciones alternativas y las comparamos con la inicial. También podemos exportarlas en JSON para recuperarlas más adelante».

**4:20–4:40 | Conclusión**
«Nuestra conclusión es que en Cournot una empresa no escoge su producción de manera aislada: su mejor decisión depende de cuánto produce el rival. Un equilibrio se alcanza cuando ambas decisiones son mejores respuestas simultáneas».

**Consejo de grabación:** Antes de grabar, restablecer el mercado. Mantener visibles la barra lateral, las curvas y el cuadro de beneficios. Si el tiempo queda corto, resumir la explicación de cada pestaña sin omitir el caso de la empresa rival.

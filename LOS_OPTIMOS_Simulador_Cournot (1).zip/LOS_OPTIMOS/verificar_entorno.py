"""Revisión de software local en el computador donde se ejecute este script."""
import importlib.util
import platform
import shutil
import sys

print("="*55)
print(" LOS OPTIMOS | DIAGNÓSTICO DE TU COMPUTADOR")
print("="*55)
print(f"Sistema operativo: {platform.platform()}")
print(f"Python detectado: {sys.version.split()[0]}")
print(f"Ruta de Python: {sys.executable}")
print("Versión recomendada: Python 3.11, 3.12 o 3.13")
print("VS Code:", shutil.which('code') or "no aparece en PATH; puede estar instalado sin el comando 'code'")
print("Streamlit:", "instalado" if importlib.util.find_spec('streamlit') else "falta instalar")
print("Plotly:", "instalado" if importlib.util.find_spec('plotly') else "falta instalar")
print("NumPy:", "instalado" if importlib.util.find_spec('numpy') else "falta instalar")
print("Pandas:", "instalado" if importlib.util.find_spec('pandas') else "falta instalar")
print("\nPara instalar dependencias: python -m pip install -r requirements.txt")
print("Para iniciar la app:        python -m streamlit run app.py")

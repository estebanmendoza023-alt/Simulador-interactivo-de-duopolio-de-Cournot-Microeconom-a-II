# LOS OPTIMOS — Registro de validación técnica

## Comprobado en este entorno

- La aplicación principal y sus módulos Python **compilan** sin errores de sintaxis (`python -m py_compile`).
- El cálculo del caso inicial produce **q1 = q2 = 26,666666…, Q = 53,333333…, P = 46,666666…, π1 = π2 = 711,111111…**.
- Se ejecutaron **15 pruebas automatizadas** y finalizaron correctamente. Estas incluyen 1.000 combinaciones aleatorias de parámetros válidos.
- Los casos extremos `c1 = 95, c2 = 20`, `c1 = 20, c2 = 95` y `c1 = 120, c2 = 140` se resolvieron sin producciones negativas.
- Se comprobaron, para cada equilibrio de prueba, las funciones de reacción y los criterios de complementariedad, así como la optimalidad frente a varias desviaciones unilaterales.
- Los cálculos y trazas de Plotly se generaron y probaron con q1 en el eje X y q2 en Y.
- El PDF de 8 páginas se generó, convirtió a imágenes para su inspección y se revisó visualmente.

## Pendiente en el computador del usuario

**La aplicación Streamlit NO se ha podido arrancar aquí ni se ha comprobado en un navegador real.** La biblioteca Streamlit no estaba instalada en este entorno de creación y el acceso a PyPI estaba bloqueado, por lo que falló la descarga. Esto no significa que el proyecto tenga un fallo; significa que no podemos afirmar que las interacciones visuales funcionan hasta ejecutar la app en un equipo con sus dependencias.

Para completar la verificación en tu equipo:

1. Ejecutar `python verificar_entorno.py` para identificar Python, VS Code y bibliotecas en ese computador.
2. Iniciar la app mediante `ejecutar_windows.bat` o `bash ejecutar_mac_linux.sh`.
3. Comprobar en el navegador todas las pestañas, moviendo `a`, `b`, `c1` y `c2` por separado.
4. Verificar los resultados de base, el caso de esquina con `c1=95`, y un escenario manual distinto del equilibrio.
5. Guardar dos escenarios, seleccionar uno como referencia, comprobar que las curvas cambian y exportar/importar el JSON.
6. Ejecutar `python -m pip install pytest` y `python -m pytest -q` dentro de la carpeta.

No se ha inspeccionado ni modificado el computador personal del usuario.

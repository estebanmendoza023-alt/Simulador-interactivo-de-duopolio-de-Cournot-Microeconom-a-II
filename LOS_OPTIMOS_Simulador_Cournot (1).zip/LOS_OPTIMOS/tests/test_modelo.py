"""Pruebas unitarias sin dependencias de Streamlit."""
from math import isclose
import random
import pytest

from modelo import Mercado, equilibrio, reaccion1, reaccion2, evaluar
from graficas import grafica_reacciones, grafica_beneficio, grafica_escenarios
from explicaciones import curva_desplazada, descripcion_cambios


def cerca(real, esperado, tol=1e-6):
    assert isclose(real, esperado, abs_tol=tol), (real, esperado)


def test_resultados_iniciales():
    m = Mercado(100, 1, 20, 20)
    r = equilibrio(m)
    cerca(r.q1, 80/3)
    cerca(r.q2, 80/3)
    cerca(r.q_total, 160/3)
    cerca(r.precio, 140/3)
    cerca(r.beneficio1, 6400/9)
    cerca(r.beneficio2, 6400/9)
    cerca(r.ingreso1, (140/3)*(80/3))
    cerca(r.costo1, 20*(80/3))
    assert r.tipo == "Equilibrio interior"


@pytest.mark.parametrize("m,q1,q2,tipo", [
    (Mercado(100, 1, 95, 20), 0, 40, "empresa 2"),
    (Mercado(100, 1, 20, 95), 40, 0, "empresa 1"),
    (Mercado(100, 1, 120, 140), 0, 0, "inactivas"),
    (Mercado(100, 1, 100, 20), 0, 40, "empresa 2"),
    (Mercado(100, 1, 20, 100), 40, 0, "empresa 1"),
    (Mercado(100, 1, 100, 100), 0, 0, "inactivas"),
])
def test_casos_de_esquina(m,q1,q2,tipo):
    r = equilibrio(m)
    cerca(r.q1,q1)
    cerca(r.q2,q2)
    assert tipo in r.tipo
    cerca(reaccion1(m,r.q2),r.q1)
    cerca(reaccion2(m,r.q1),r.q2)


def test_parametros_restricciones():
    for args in [(100,0,20,20),(-1,1,0,0),(10,1,-1,0),(10,1,0,-1)]:
        with pytest.raises(ValueError):
            Mercado(*args)
    with pytest.raises(ValueError):reaccion1(Mercado(),-1)
    with pytest.raises(ValueError):reaccion2(Mercado(),-1)
    with pytest.raises(ValueError):evaluar(Mercado(),-1,2)


def test_variar_cada_parametro():
    base=equilibrio(Mercado())
    por_costo1=equilibrio(Mercado(100,1,35,20))
    assert por_costo1.q1<base.q1 and por_costo1.q2>base.q2
    por_costo2=equilibrio(Mercado(100,1,20,10))
    assert por_costo2.q2>base.q2 and por_costo2.q1<base.q1
    por_demanda=equilibrio(Mercado(120,1,20,20))
    assert por_demanda.q1>base.q1 and por_demanda.q2>base.q2
    por_pendiente=equilibrio(Mercado(100,2,20,20))
    cerca(por_pendiente.q1,base.q1/2)
    cerca(por_pendiente.precio,base.precio)


def test_reacciones_descendentes():
    m=Mercado(100,1,20,20)
    assert reaccion1(m,15)>reaccion1(m,30)
    assert reaccion2(m,15)>reaccion2(m,30)
    cerca(reaccion1(m,200),0)
    cerca(reaccion2(m,200),0)


def test_manual_diferente_de_equilibrio_y_maximizacion():
    m=Mercado()
    r=equilibrio(m)
    q_rival=r.q2
    opt=reaccion1(m,q_rival)
    alternativa=evaluar(m,10,q_rival)
    optima=evaluar(m,opt,q_rival)
    assert alternativa.beneficio1<optima.beneficio1
    assert alternativa.q1!=r.q1


def test_random_equilibrios_y_kkt():
    rng=random.Random(2207)
    for _ in range(1000):
        m=Mercado(a=rng.uniform(10,300),b=rng.uniform(.1,10),
                  c1=rng.uniform(0,300),c2=rng.uniform(0,300))
        r=equilibrio(m)
        assert r.q1>=0 and r.q2>=0
        cerca(r.q1,reaccion1(m,r.q2),1e-7)
        cerca(r.q2,reaccion2(m,r.q1),1e-7)
        assert r.precio>=-1e-7
        assert r.beneficio1>=-1e-7 and r.beneficio2>=-1e-7
        g1=m.a-m.c1-2*m.b*r.q1-m.b*r.q2
        g2=m.a-m.c2-2*m.b*r.q2-m.b*r.q1
        assert g1<=1e-7 and g2<=1e-7
        assert abs(r.q1*g1)<=1e-6 and abs(r.q2*g2)<=1e-6
        # Desviaciones unilaterales nunca mejoran el beneficio de Nash.
        for nueva_q in (0, r.q1*.5, r.q1*1.3, max(.0,r.q1+3)):
            assert evaluar(m,nueva_q,r.q2).beneficio1 <= r.beneficio1 + 1e-6
        for nueva_q in (0,r.q2*.5,r.q2*1.3,max(.0,r.q2+3)):
            assert evaluar(m,r.q1,nueva_q).beneficio2 <= r.beneficio2 + 1e-6


def test_grafica_convencion_ejes_y_referencia():
    m=Mercado()
    fig=grafica_reacciones(m, Mercado(110,1,20,20))
    assert len(fig.data)==6
    reaccion1_actual=fig.data[3]
    reaccion2_actual=fig.data[4]
    for x,y in zip(reaccion1_actual.x[::20],reaccion1_actual.y[::20]):
        cerca(x,reaccion1(m,y))
    for x,y in zip(reaccion2_actual.x[::20],reaccion2_actual.y[::20]):
        cerca(y,reaccion2(m,x))
    r=equilibrio(m)
    cerca(fig.data[-1].x[0],r.q1)
    cerca(fig.data[-1].y[0],r.q2)
    assert len(grafica_reacciones(m).data)==3


def test_graficas_escenarios_y_beneficios():
    assert len(grafica_beneficio(Mercado(),1,20,40).data)==3
    assert len(grafica_escenarios({"Inicial":Mercado(),"Nuevo":Mercado(100,1,35,20)}).data)==3


def test_explica_cambios_en_esquina():
    mensaje=" ".join(descripcion_cambios(Mercado(100,1,95,20),Mercado()))
    assert "esquina" in mensaje.lower()
    assert "R₁" in curva_desplazada(Mercado(100,1,35,20),Mercado())
    assert "R₂" not in curva_desplazada(Mercado(100,1,35,20),Mercado())
